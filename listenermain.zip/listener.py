import os
import socket
import shlex
import base64
from pathlib import Path
import sys

HOST = "0.0.0.0"
PORT = 5443
DOWNLOAD_PATH = "downloads"

def save_downloaded_file(data, original_filename):
    try:
        if not os.path.exists(DOWNLOAD_PATH):
            os.makedirs(DOWNLOAD_PATH)

        file_data = base64.b64decode(data.strip())
        file_path = os.path.join(DOWNLOAD_PATH, original_filename)

        with open(file_path, 'wb') as f:
            f.write(file_data)

        print(f"\n[i] Saved downloaded file to {file_path}\n")
        return True
    except Exception as e:
        print(f'Error saving downloaded file: {e}')
        return False

def handle_client(conn, addr):
    print(f"[i] New connection from {addr[0]}:{addr[1]}")

    try:
        initial_msg = conn.recv(1024).decode('utf-8', errors='ignore')
        if initial_msg:
            print(initial_msg, end='')

        while True:
            try:
                command = input(f'{addr[0]}> ').strip()
                if not command:
                    continue

                if command.startswith("/download "):
                    try:
                        parts = shlex.split(command)
                        if len(parts) < 2:
                            print("Usage: /download <filename>\n")
                            continue

                        print(f"[DEBUG] Sending Command: {command}")
                        conn.send(command.encode() + b'\n')

                        buffer = b""
                        in_file = False
                        filename = None

                        conn.settimeout(10.0)

                        while True:
                            try:
                                print(f"[DEBUG] Awaiting data... (buffer: {len(buffer)} bytes)")
                                chunk = conn.recv(4096)
                                if not chunk:
                                    print("[DEBUG] Connection closed by client.")
                                    break

                                print(f"[DEBUG] Received {len(chunk)} bytes chunk.")
                                buffer += chunk

                                if b'[FILE START]' in buffer and not in_file:
                                    print("[DEBUG] Found [FILE START]")
                                    in_file = True
                                    parts = buffer.split(b'[FILE START]')
                                    header = parts[0].decode('utf-8', errors='ignore')
                                    print(header, end='')

                                    for line in header.split('\n'):
                                        if 'Filename:' in line:
                                            filename = line.split(':')[1].strip()
                                            print(f"[DEBUG] Filename extracted: {filename}")
                                    buffer = parts[1]

                                if b'[FILE END]' in buffer:
                                    print("[DEBUG] Found [FILE END]")
                                    file_data = buffer.split(b'[FILE END]')[0]
                                    if filename:
                                        save_downloaded_file(file_data.decode('utf-8'), filename)
                                    else:
                                        print("Could not find filename.")
                                    break
                            except socket.timeout:
                                print(f"[DEBUG] TIMEOUT! Buffer has: {len(buffer)} bytes")
                                print(f"[DEBUG] First 200 bytes from buffer: {buffer[:200]}")
                                print("Connection timeout.")
                                break

                        conn.settimeout(2.0)
                        continue

                    except ValueError as e:
                        print(f"Invalid command syntax: {e}")
                        continue

                conn.send(command.encode() + b'\n')
                if command == "/exit":
                    print("\nClient disconnected.")
                    break
                response = b""
                conn.settimeout(2.0)
                while True:
                    try:
                        chunk = conn.recv(4096)
                        if not chunk:
                            break
                        response += chunk
                    except socket.timeout:
                        break
                if response:
                    decoded = response.decode('utf-8', errors='ignore')
                    print(decoded, end='')
                else:
                    print("\nNo response from client.")

            except KeyboardInterrupt:
                print("Interrupted by user.")
                conn.send(b'/exit\n')
                break
            except Exception as e:
                print(f'Error command-response: {e}')

    except Exception as e:
        print(f'Error handle_client: {e}')
    finally:
        conn.close()
        print("\nConnection closed.")

def start_listener():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen(5)

        print(f'[i] Listening on {HOST}:{PORT}')
        print(f'[i] Waiting for connection...\n')

        while True:
            try:
                conn, addr = s.accept()
                handle_client(conn, addr)

                print("\n")
                choice = input("Wait for new connection? (y/n) ").lower()
                if choice != "y":
                    print("Shutting down...")
                    break
                print(f'[i] Waiting for connection...\n')
            except KeyboardInterrupt:
                print("Interrupted by user.")
                break
    except Exception as e:
        print(f'Listener Error: {e}')

    finally:
        s.close()
        print("\nListener closed.")

if __name__ == "__main__":
    try:
        start_listener()
    except KeyboardInterrupt:
        print(f'Exiting...')
        sys.exit()
